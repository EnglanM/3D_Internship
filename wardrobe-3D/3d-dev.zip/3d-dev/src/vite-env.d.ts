/// <reference types="vite/client" />

declare type MouseWheelEvent = WheelEvent;